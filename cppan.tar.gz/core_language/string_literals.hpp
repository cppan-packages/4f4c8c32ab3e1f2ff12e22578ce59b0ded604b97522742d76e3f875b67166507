#pragma once
// #include <p/expressive/core_language/string_literals.hpp>
// Copyright � 2017 Alf P. Steinbach, distributed under Boost license 1.0.

namespace progrock{ namespace expressive {
#include <p/expressive/pseudo_keywords/begin_region.hpp>
    inline namespace core {

    }  // namespace core
#include <p/expressive/pseudo_keywords/end_region.hpp>
}}  // namespace progrock::expressive
