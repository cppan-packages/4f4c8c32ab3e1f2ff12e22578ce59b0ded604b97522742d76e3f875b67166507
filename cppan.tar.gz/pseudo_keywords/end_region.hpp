// Can't use `#pragma once` for this header; it's re-includable like `assert.h`.
// #include <p/expressive/pseudo_keywords/end_region.hpp>
// Copyright � 2017 Alf P. Steinbach, distributed under Boost license 1.0.

#include <p/expressive/pseudo_keywords/impl/pop_macro_definitions.hpp>
