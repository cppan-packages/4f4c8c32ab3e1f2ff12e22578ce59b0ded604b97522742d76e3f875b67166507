#pragma once
// #include <p/stdlib/forward_declarations_for_iostreams.hpp>
// Copyright � 2017 Alf P. Steinbach, distributed under Boost license 1.0.

#include <iosfwd>
