#pragma once
// #include <p/expressive/use_weakly_all.hpp>
// Copyright � 2017 Alf P. Steinbach, distributed under Boost license 1.0.

#include <p/expressive/all.hpp>
$use_weakly_all_from( progrock::expressive );
